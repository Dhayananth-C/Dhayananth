package section2;

public class methods {
		  public int addNumbers(int x, int y) {
		    int add = x + y;
		    return add;
		  }
		  public static void main(String[] args) {
		    int number1 = 50;
		    int number2 = 01;
		    methods obj = new methods();
		    int result = obj.addNumbers(number1, number2);
		    System.out.println("add is: " + result);
		  }
		}


