package section2;

public class Array {

		public static void main(String[] args) {

		//single-dimensional array
		int a[]= {20,30,10,40,60};
		for(int i=0;i<5;i++) {
		System.out.println("Elements of array a: "+a[i]);
		}


		//multidimensional array
		int[][] b = {{16,26,40,85}, 
		            {40,155,143} };
		      
		      System.out.println("\nLength of row 2: " + b[1].length);
		      }
		}


