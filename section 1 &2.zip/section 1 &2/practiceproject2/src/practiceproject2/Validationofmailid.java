package practiceproject2;
import java.util.ArrayList;
import java.util.Scanner;
public class Validationofmailid {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		ArrayList<String> mail = new ArrayList<String>();
		mail.add("deepa@gmail.com");
		mail.add("dhaya14@gmail.com");
		mail.add("bhuvi2233@gmail.com");
		mail.add("saran@gmail.com");
		mail.add("kotasamy@gmail.com");
		System.out.println("ENTER USER EMAIL ID:");
		String userId = input.nextLine();
		
			if (mail.contains(userId)) {
				System.out.println();
				System.out.println("Email ID : " + userId + " is found");
			} 
			else {
				System.out.println("Email ID : " + userId + " is Not found");

			}
			input.close();
		}
	}

