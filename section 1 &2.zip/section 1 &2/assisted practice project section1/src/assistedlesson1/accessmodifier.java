package assistedlesson1;

public class accessmodifier {
	
	    private String name;
	    public String getName() {
	        return this.name;
	    }
	    public void setName(String name) {
	        this.name= name;
	    }
	}
	class Main {
	    public static void main(String[] main){
	        accessmodifier d = new accessmodifier();
	        d.setName("Simplilearn Access modifier");
	        System.out.println(d.getName());
	    }
	}


