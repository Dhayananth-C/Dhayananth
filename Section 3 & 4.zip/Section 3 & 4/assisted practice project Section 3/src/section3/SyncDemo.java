package section3;

public class SyncDemo {
		
		    public void send(String msg) 
		    { 
		        System.out.println("Sending\t"  + msg ); 
		        try
		        { 
		            Thread.sleep(1000); 
		        } 
		        catch (Exception e) 
		        { 
		            System.out.println("Thread  interrupted."); 
		        } 
		        System.out.println("\n" + msg + "Sent"); 
		    } 
		} 
		class ThreadedSend extends Thread 
		{ 
		    private String msg; 
		    SyncDemo sender; 
		    ThreadedSend(String m,  SyncDemo obj) 
		    { 
		        msg = m; 
		        sender = obj; 
		    } 
		  
		    public void run() 
		    {  
		        synchronized(sender) 
		        { 
		            sender.send(msg); 
		        } 
		    } 
		} 
		class newSyncDemo 
		{ 
		    public static void main(String args[]) 
		    { 
		    	SyncDemo snd = new SyncDemo(); 
		        ThreadedSend S1 = 
		            new ThreadedSend( " iam good " , snd ); 
		        ThreadedSend S2 = 
		            new ThreadedSend( " ok nice " , snd ); 
		        S1.start(); 
		        S2.start(); 
		        try
		        { 
		            S1.join(); 
		            S2.join(); 
		        } 
		        catch(Exception e) 
		        { 
		            System.out.println("Interrupted"); 
		        } 
		    } 
		} 




