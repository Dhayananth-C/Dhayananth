package section3;

public class threadscreation1 {
	
	

	
		
		 	public void run()
		 	{
		  		System.out.println("concurrent thread started running..");
		}
		 	public static void main( String args[] )
		 	{
		 		threadscreation1 mt = new  threadscreation1();
		  		mt.start();
		 	}
			private void start() {
				// TODO Auto-generated method stub
				System.out.println("Welcome.");
			}
		}



